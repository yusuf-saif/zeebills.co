-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 28, 2025 at 12:01 AM
-- Server version: 10.6.22-MariaDB-cll-lve-log
-- PHP Version: 8.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `deriplug_zeebills`
--

-- --------------------------------------------------------

--
-- Table structure for table `airtime`
--

CREATE TABLE `airtime` (
  `aId` int(100) NOT NULL,
  `aNetwork` varchar(10) NOT NULL,
  `aBuyDiscount` float NOT NULL DEFAULT 96,
  `aUserDiscount` float NOT NULL,
  `aAgentDiscount` float NOT NULL,
  `aVendorDiscount` float NOT NULL,
  `aType` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `airtime`
--

INSERT INTO `airtime` (`aId`, `aNetwork`, `aBuyDiscount`, `aUserDiscount`, `aAgentDiscount`, `aVendorDiscount`, `aType`) VALUES
(1, '1', 96, 99, 98, 97, 'VTU'),
(2, '2', 96, 99, 98, 97, 'VTU'),
(3, '3', 97, 99, 98, 98, 'VTU'),
(4, '4', 97, 99, 98, 98.5, 'VTU'),
(5, '1', 96, 99, 99, 98, 'Share And Sell'),
(6, '2', 96, 99, 98, 97, 'Share And Sell'),
(7, '3', 100, 100, 100, 100, 'Share And Sell'),
(8, '4', 97, 99, 98, 98, 'Share And Sell');

-- --------------------------------------------------------

--
-- Table structure for table `airtimepinprice`
--

CREATE TABLE `airtimepinprice` (
  `aId` int(100) NOT NULL,
  `aNetwork` varchar(10) NOT NULL,
  `aUserDiscount` float NOT NULL,
  `aAgentDiscount` float NOT NULL,
  `aVendorDiscount` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `airtimepinprice`
--

INSERT INTO `airtimepinprice` (`aId`, `aNetwork`, `aUserDiscount`, `aAgentDiscount`, `aVendorDiscount`) VALUES
(1, '1', 100, 100, 99),
(2, '2', 100, 100, 99),
(3, '3', 100, 100, 98),
(4, '4', 100, 100, 98);

-- --------------------------------------------------------

--
-- Table structure for table `apiconfigs`
--

CREATE TABLE `apiconfigs` (
  `aId` int(200) NOT NULL,
  `name` varchar(30) NOT NULL,
  `value` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `apiconfigs`
--

INSERT INTO `apiconfigs` (`aId`, `name`, `value`) VALUES
(1, 'monifyCharges', '50'),
(2, 'monifyApi', 'MK_PROD_TRY9VD'),
(3, 'monifySecrete', 'DGF9HC0ST2315YVX'),
(4, 'monifyContract', '36156'),
(5, 'monifyWeStatus', 'On'),
(6, 'monifyMoStatus', 'On'),
(7, 'monifyFeStatus', 'Off'),
(8, 'monifySaStatus', 'On'),
(9, 'monifyStatus', 'On'),
(10, 'paystackCharges', '1.7'),
(11, 'paystackApi', 'Something'),
(12, 'paystackStatus', 'On'),
(13, 'mtnVtuKey', '8b0f6dde53f40a53177ec'),
(14, 'mtnVtuProvider', 'sub.com/api/topup/'),
(15, 'mtnSharesellKey', 'fhhhbfd'),
(16, 'mtnSharesellProvider', 'https://husmodataapi.com/api/topup/'),
(17, 'airtelVtuKey', '5aef8b0f6dde53f40a53177ec'),
(18, 'airtelVtuProvider', 'https://datapointsub.com/api/topup/'),
(19, 'airtelSharesellKey', 'Gsggdgdgd'),
(20, 'airtelSharesellProvider', 'https://husmodataapi.com/api/topup/'),
(21, 'gloVtuKey', '0f6dde53f40a53177ec'),
(22, 'gloVtuProvider', 'https://datapointsub.com/api/topup/'),
(23, 'gloSharesellKey', 'Hshhshhehhhebehe'),
(24, 'gloSharesellProvider', 'https://gongozconcept.com/api/topup/'),
(25, '9mobileVtuKey', 'aef8b0f6dde53f40a53177ec'),
(26, '9mobileVtuProvider', 'https://datapointsub.com/api/topup/'),
(27, '9mobileSharesellKey', 'Hhggfwssdfggggc'),
(28, '9mobileSharesellProvider', 'https://gongozconcept.com/api/topup/'),
(29, 'mtnSmeApi', 'be025792aa3f3fcac72280b'),
(30, 'mtnSmeProvider', 'https://masuddatasub.com/api/data/'),
(31, 'mtnGiftingApi', '5A4D6ndHB8oCl2hyxr8GC31AzBcACC4wFCAi7kxg3CbCBcsA2C3paB05Cq3t1708727765'),
(32, 'mtnGiftingProvider', 'https://ausadvtu.com/api/data/'),
(33, 'mtnCorporateApi', '025792aa3f3fcac72280b'),
(34, 'mtnCorporateProvider', 'https://masuddatasub.com/api/data/'),
(35, 'airtelSmeApi', 'Gggjhffvv'),
(36, 'airtelSmeProvider', 'https://husmodataapi.com/api/data/'),
(37, 'airtelGiftingApi', 'Ggghv'),
(38, 'airtelGiftingProvider', 'https://gongozconcept.com/api/data/'),
(39, 'airtelCorporateApi', '25792aa3f3fcac72280b'),
(40, 'airtelCorporateProvider', 'https://masuddatasub.com/api/data/'),
(41, 'gloSmeApi', 'Yesterdayeverything'),
(42, 'gloSmeProvider', 'https://husmodataapi.com/api/data/'),
(43, 'gloGiftingApi', '6dde53f40a53177ec'),
(44, 'gloGiftingProvider', 'https://masuddatasub.com/api/data/'),
(45, 'gloCorporateApi', 'e6e24acd9b070131bbe025792aa3f3fcac72280b'),
(46, 'gloCorporateProvider', 'https://masuddatasub.com/api/data/'),
(47, '9mobileSmeApi', '5aef8b0f6dde53f40a53177ec'),
(48, '9mobileSmeProvider', 'https://datapointsub.com/api/data/'),
(49, '9mobileGiftingApi', 'Something like this '),
(50, '9mobileGiftingProvider', 'https://maskawasub.com/api/data/'),
(51, '9mobileCorporateApi', '&2307u3639405b8870abe443b6'),
(52, '9mobileCorporateProvider', 'https://rbsdataapi.com.ng/api/data/'),
(53, 'cableVerificationApi', 'c68ad3032dea5c15e0c7a4cc'),
(54, 'cableVerificationProvider', 'https://masuddatasub.com/api/cablesub/id'),
(55, 'cableApi', '68ad3032dea5c15e0c7a4cc'),
(56, 'cableProvider', 'https://masuddatasub.com/api/cablesub/'),
(57, 'meterVerificationApi', '3032dea5c15e0c7a4cc'),
(58, 'meterVerificationProvider', 'https://masuddatasub.com/api/billpayment/id'),
(59, 'meterApi', '32dea5c15e0c7a4cc'),
(60, 'meterProvider', 'https://masuddatasub.com/api/billpayment/'),
(61, 'examApi', 'ec68ad3032dea5c15e0c7a4cc'),
(62, 'examProvider', 'https://masuddatasub.com/Result-Checker-Pin-order/'),
(63, 'rechargePinApi', 'Yesterday'),
(64, 'rechargePinProvider', 'ejbejecatwyehvdjdjrhrbr'),
(65, 'walletOneApi', 'e6e24acd9b070131bbe025792aa3f3fcac72280b'),
(66, 'walletOneProvider', 'https://masuddatasub.com/api/user/'),
(67, 'walletOneProviderName', 'Masuddatasub'),
(68, 'walletTwoApi', '5aef8b0f6dde53f40a53177ec'),
(69, 'walletTwoProvider', 'https://datapointsub.com/api/user/'),
(70, 'walletTwoProviderName', 'Datapointsub'),
(71, 'walletThreeApi', '5A4D3t1708727765'),
(72, 'walletThreeProvider', 'https://ausadvtu.com/api/user/'),
(73, 'walletThreeProviderName', 'AUSAD VTU'),
(74, 'walletFourApi', 'q3t1708727765'),
(75, 'walletFourProvider', 'https://ausadvtu.com/api/user/'),
(76, 'walletFourProviderName', 'AUSAD VTU'),
(77, 'walletFiveApi', '..'),
(78, 'walletFiveProvider', 'https://bilalsadasub.com.ng'),
(79, 'walletFiveProviderName', 'Mo'),
(80, 'walletSixApi', 'QFN1bnVzaTgya2t1'),
(81, 'walletSixProvider', 'https://bilalsadasub.com.ng'),
(82, 'walletSixProviderName', 'Bilalsadasub '),
(83, 'airtime2cashstatus', 'On'),
(84, 'airtime2cashmtnno', '07026417709'),
(85, 'airtime2cashmtnrate', '80'),
(86, 'airtime2cashairtelno', '09047223564'),
(87, 'airtime2cashairtelrate', '70'),
(88, 'airtime2cashglono', '0'),
(89, 'airtime2cashglorate', '0'),
(90, 'airtime2cash9mobilerate', '0'),
(91, 'asfiyApi', '8964949703abcc'),
(92, 'asfiyWebhook', 'https://my.vtutelecom.com.ng/webhook/aspfiy/index.php'),
(93, 'asfiyChargesType', 'flat'),
(94, 'asfiyCharges', '30'),
(95, 'asfiyStatus', 'On');

-- --------------------------------------------------------

--
-- Table structure for table `apilinks`
--

CREATE TABLE `apilinks` (
  `aId` int(200) NOT NULL,
  `name` varchar(30) NOT NULL,
  `value` varchar(100) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cableid`
--

CREATE TABLE `cableid` (
  `cId` int(11) NOT NULL,
  `cableid` varchar(10) DEFAULT NULL,
  `provider` varchar(10) NOT NULL,
  `providerStatus` varchar(10) NOT NULL DEFAULT 'On'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `cableid`
--

INSERT INTO `cableid` (`cId`, `cableid`, `provider`, `providerStatus`) VALUES
(1, '1', 'GOTV', 'On'),
(2, '2', 'DSTV', 'On'),
(3, '3', 'STARTIMES', 'On');

-- --------------------------------------------------------

--
-- Table structure for table `cableplans`
--

CREATE TABLE `cableplans` (
  `cpId` int(100) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `userprice` varchar(255) NOT NULL,
  `agentprice` varchar(255) NOT NULL,
  `vendorprice` varchar(255) NOT NULL,
  `planid` varchar(255) NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  `cableprovider` tinyint(10) NOT NULL,
  `day` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `cableplans`
--

INSERT INTO `cableplans` (`cpId`, `name`, `price`, `userprice`, `agentprice`, `vendorprice`, `planid`, `type`, `cableprovider`, `day`) VALUES
(1, 'DStv Padi', '2500', '2520', '2515', '2514', '1', NULL, 2, '30'),
(2, 'DSTV -YANGA', '3500', '3520', '3515', '35114', '2', NULL, 2, '30'),
(3, 'DStv Premium-Asia', '24500', '24520', '24515', '24514', '9', NULL, 2, '30'),
(4, 'DStv Confam + ExtraView', '7115', '7125', '7120', '7119', '10', NULL, 2, '30'),
(5, 'Dstv Confam', '6200', '6220', '6215', '6214', '34', NULL, 2, '30'),
(6, 'DStv Compact', '10500', '10520', '10515', '10514', '35', NULL, 2, '30'),
(7, 'DStv Premium', '21000', '21020', '21015', '21014', '36', NULL, 2, '30'),
(8, 'DStv Asia', '7100', '7120', '7115', '719', '37', NULL, 1, '30'),
(9, 'DStv Compact Plus', '16600', '16620', '16615', '16614', '38', NULL, 2, '30'),
(10, 'DStv Padi + ExtraView', '5050', '5070', '5065', '5064', '43', NULL, 2, '30'),
(11, 'GOtv Max', '4850', '4870', '4865', '4864', '59', NULL, 1, '30'),
(12, 'GOtv Jolli', '3300', '3320', '3315', '3314', '60', NULL, 2, '30'),
(13, 'GOtv Jinja', '2250', '2270', '2265', '2264', '61', NULL, 1, '30'),
(14, 'GOtv Smallie - monthly', '1100', '1120', '1115', '1114', '62', NULL, 1, '30'),
(15, 'GOtv Supa - monthly', '6400', '6420', '6415', '6414', '65', NULL, 1, '30'),
(16, 'Nova - 1 Month', '1200', '1220', '1215', '1214', '66', NULL, 3, '30'),
(17, 'Basic (Antenna) - 1 Month', '2100', '2120', '2115', '2114', '67', NULL, 3, '30'),
(18, 'Smart (Dish) -1 Month', '2800', '2820', '2815', '2814', '68', NULL, 3, '30'),
(19, 'Classic (Antenna) - 1 Month', '3100', '3120', '3115', '3114', '69', NULL, 3, '30'),
(20, 'Super (Dish) - 1 Month', '5300', '5320', '5315', '5314', '70', NULL, 3, '30'),
(21, 'Nova - 1 Week', '400', '420', '415', '414', '71', NULL, 3, '30'),
(22, 'Basic (Antenna) - 1 Week', '700', '720', '715', '714', '72', NULL, 3, '30'),
(23, 'Smart (Dish) -- 1 Week', '900', '920', '915', '914', '73', NULL, 3, '30'),
(24, 'Classic (Antenna) - 1 Week', '1200', '1220', '1215', '1214', '74', NULL, 3, '30'),
(25, 'Super (Dish) - 1 Week', '1800', '1820', '1815', '1814', '75', NULL, 3, '30');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `msgId` int(200) NOT NULL,
  `sId` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `contact` varchar(200) NOT NULL,
  `subject` varchar(200) NOT NULL,
  `message` text NOT NULL,
  `dPosted` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`msgId`, `sId`, `name`, `contact`, `subject`, `message`, `dPosted`) VALUES
(10, 0, 'Emmanuel Obianigwe', 'obianigweemmanuel26@gmail.com', '09131096068', 'I funded my wallet but I haven&#39;t seen it\r\n', '2024-02-19 23:18:01'),
(11, 0, 'Usman Ahmad beli', 'uahmadbeli@gmail.com', 'Question', 'How do I upgrade my account', '2024-02-20 08:46:47'),
(12, 0, 'Ibrahim Aliyu', 'galadima8800@gmail.com', 'Request ', 'I forget my transaction pin', '2024-02-21 15:57:48'),
(13, 0, 'Abubakar Abdulkarim', 'abdulkarimabubakar849@gmail.com', 'Pls attend me', 'Why is shows me incorrect pin', '2024-02-21 23:20:24'),
(14, 0, 'Abubakar Abdulkarim', 'abdulkarimabubakar849@gmail.com', 'Pin issue', 'I forget my pin please,how can i recover it', '2024-02-22 10:07:11');

-- --------------------------------------------------------

--
-- Table structure for table `datapins`
--

CREATE TABLE `datapins` (
  `dpId` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `userprice` varchar(255) NOT NULL,
  `agentprice` varchar(255) NOT NULL,
  `vendorprice` varchar(255) NOT NULL,
  `planid` varchar(255) NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  `datanetwork` tinyint(4) NOT NULL,
  `day` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `datapins`
--

INSERT INTO `datapins` (`dpId`, `name`, `price`, `userprice`, `agentprice`, `vendorprice`, `planid`, `type`, `datanetwork`, `day`) VALUES
(60, '500MB', '145', '150', '150', '150', '1', 'Gifting', 1, '30'),
(61, 'Vb', '66', '666', '66', '66', '66', 'SME', 1, '666'),
(62, 'Vv', '55', '55', '555', '88', '5', 'Corporate', 4, '55');

-- --------------------------------------------------------

--
-- Table structure for table `dataplans`
--

CREATE TABLE `dataplans` (
  `pId` int(100) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `userprice` varchar(255) NOT NULL,
  `agentprice` varchar(255) NOT NULL,
  `vendorprice` varchar(255) NOT NULL,
  `planid` varchar(255) NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  `datanetwork` tinyint(10) NOT NULL,
  `day` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `dataplans`
--

INSERT INTO `dataplans` (`pId`, `name`, `price`, `userprice`, `agentprice`, `vendorprice`, `planid`, `type`, `datanetwork`, `day`) VALUES
(12, '500MB', '128', '134', '134', '133', '291', 'SME', 1, '30'),
(13, '1GB', '254', '257', '257', '256', '292', 'SME', 1, '30'),
(14, '2GB', '510', '518', '518', '515', '293', 'SME', 1, '30'),
(15, '3GB', '765', '799', '799', '785', '294', 'SME', 1, '30'),
(16, '5GB', '1275', '1299', '1280', '1285', '295', 'SME', 1, '30'),
(17, '10GB', '2550', '2590', '2570', '2570', '296', 'SME', 1, '30'),
(18, '500MB Airtel ', '100', '110', '108', '108', '335', 'Corporate', 4, '30'),
(19, '1GB Airtel ', '200', '209', '208', '207', '336', 'Corporate', 4, '30'),
(20, '2GB Airtel ', '400', '418', '416', '416', '337', 'Corporate', 4, '30'),
(21, '5GB Airtel', '1000', '1045', '1042', '1050', '338', 'Corporate', 4, '30'),
(23, '10GB Airtel', '2000', '2090', '2050', '2100', '339', 'Corporate', 4, '30'),
(24, '15GB Airtel ', '3000', '3135', '3075', '3135', '340', 'Corporate', 4, '30'),
(25, '1GB GLO', '225', '230', '228', '230', '355', 'Corporate', 2, '30'),
(26, '2GB GLO ', '450', '460', '455', '460', '356', 'Corporate', 2, '30'),
(27, '3GB GLO', '675', '690', '690', '690', '357', 'Corporate', 2, '30'),
(28, '5GB GLO', '1710', '1800', '1800', '1800', '358', 'Corporate', 2, '30'),
(29, '10GB GLO ', '2600', '2700', '2700', '2700', '199', 'Gifting', 2, '30'),
(30, '500MB GLO', '68', '75', '75', '75', '413', 'Corporate', 2, '30'),
(31, '500MB MTN ', '129', '136', '135', '135', '306', 'Corporate', 1, '30'),
(32, '1GB MTN ', '257', '265', '263', '265', '307', 'Corporate', 1, '30'),
(33, '2GB MTN', '514', '530', '520', '530', '308', 'Corporate', 1, '30'),
(34, '3GB MTN', '771', '795', '777', '799', '309', 'Corporate', 1, '30'),
(35, '5GB MTN ', '1285', '1325', '1295', '1325', '310', 'Corporate', 1, '30'),
(36, '10GB MTN', '2570', '2650', '2590', '2650', '311', 'Corporate', 1, '30'),
(37, '500MB 9MOBILE', '85', '95', '95', '95', '255', 'SME', 3, '30'),
(38, '1GB 9MOBILE', '165', '180', '180', '180', '256', 'SME', 3, '30'),
(39, '1.5GB 9MOBILE', '260', '270', '270', '270', '257', 'SME', 3, '30'),
(40, '3GB 9MOBILE', '500', '540', '539', '539', '259', 'SME', 3, '30'),
(41, '5GB 9MOBILE', '850', '900', '900', '900', '260', 'SME', 3, '30'),
(42, '10GB 9MOBILE', '1700', '1800', '1800', '1800', '261', 'SME', 3, '30'),
(44, '750MB', '205', '210', '210', '209', '72', 'Gifting', 1, '30'),
(59, '1GB', '250', '255', '255', '242', '73', 'Gifting', 1, '30'),
(60, '2GB', '510', '518', '518', '512', '76', 'Gifting', 1, '30'),
(61, '3GB', '700', '770', '770', '719', '77', 'Gifting', 1, '30');

-- --------------------------------------------------------

--
-- Table structure for table `electricityid`
--

CREATE TABLE `electricityid` (
  `eId` int(11) NOT NULL,
  `electricityid` varchar(50) DEFAULT NULL,
  `provider` varchar(50) NOT NULL,
  `abbreviation` varchar(5) NOT NULL,
  `providerStatus` varchar(10) NOT NULL DEFAULT 'On'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `electricityid`
--

INSERT INTO `electricityid` (`eId`, `electricityid`, `provider`, `abbreviation`, `providerStatus`) VALUES
(1, '1', 'Ikeja Electric', 'IE', 'On'),
(2, '2', 'Eko Electric', 'EKEDC', 'On'),
(3, '3', 'Kano Electric', 'KEDCO', 'On'),
(4, '4', 'Port Harcourt Electric', 'PHEDC', 'On'),
(5, '5', 'Jos Electric', 'JED', 'On'),
(6, '6', 'Ibadan Electric', 'IBEDC', 'On'),
(7, '7', 'Kaduna Electric', 'KEDC', 'On'),
(8, '8', 'Abuja Electric', 'AEDC', 'On'),
(9, '10', 'Enugu Electric', 'ENUGU', 'On'),
(10, '9', 'Benin Electric', 'BENIN', 'On'),
(11, '11', 'Yola Electric', 'YOLA', 'On');

-- --------------------------------------------------------

--
-- Table structure for table `examid`
--

CREATE TABLE `examid` (
  `eId` int(11) NOT NULL,
  `examid` varchar(10) DEFAULT NULL,
  `provider` varchar(50) NOT NULL,
  `price` int(20) NOT NULL DEFAULT 0,
  `buying_price` int(20) NOT NULL DEFAULT 0,
  `providerStatus` varchar(10) NOT NULL DEFAULT 'On'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `examid`
--

INSERT INTO `examid` (`eId`, `examid`, `provider`, `price`, `buying_price`, `providerStatus`) VALUES
(1, '1', 'WAEC', 3400, 3340, 'On'),
(2, '2', 'NECO', 1170, 1150, 'On'),
(3, '3', 'NABTEB', 940, 850, 'On');

-- --------------------------------------------------------

--
-- Table structure for table `networkid`
--

CREATE TABLE `networkid` (
  `nId` int(11) NOT NULL,
  `networkid` varchar(10) NOT NULL,
  `smeId` varchar(10) NOT NULL,
  `sme2Id` varchar(10) NOT NULL,
  `giftingId` varchar(10) NOT NULL,
  `corporateId` varchar(10) NOT NULL,
  `couponId` varchar(10) NOT NULL,
  `vtuId` varchar(10) NOT NULL,
  `sharesellId` varchar(10) NOT NULL,
  `network` varchar(20) NOT NULL,
  `networkStatus` varchar(10) NOT NULL DEFAULT 'Off',
  `vtuStatus` varchar(10) NOT NULL DEFAULT 'Off',
  `sharesellStatus` varchar(10) NOT NULL DEFAULT 'Off',
  `airtimepinStatus` varchar(10) NOT NULL DEFAULT 'Off',
  `smeStatus` varchar(10) NOT NULL DEFAULT 'Off',
  `sme2Status` varchar(10) NOT NULL,
  `giftingStatus` varchar(10) NOT NULL DEFAULT 'Off',
  `corporateStatus` varchar(10) NOT NULL DEFAULT 'Off',
  `couponStatus` varchar(10) NOT NULL DEFAULT 'Off',
  `datapinStatus` varchar(10) NOT NULL DEFAULT 'Off'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `networkid`
--

INSERT INTO `networkid` (`nId`, `networkid`, `smeId`, `sme2Id`, `giftingId`, `corporateId`, `couponId`, `vtuId`, `sharesellId`, `network`, `networkStatus`, `vtuStatus`, `sharesellStatus`, `airtimepinStatus`, `smeStatus`, `sme2Status`, `giftingStatus`, `corporateStatus`, `couponStatus`, `datapinStatus`) VALUES
(1, '1', '1', '1', '1', '1', '1', '1', '1', 'MTN', 'On', 'Off', 'Off', 'Off', 'On', 'On', 'On', 'On', 'Off', 'On'),
(2, '2', '2', '2', '2', '2', '2', '2', '2', 'GLO', 'On', 'On', 'Off', 'On', 'Off', 'Off', 'Off', 'On', 'Off', 'Off'),
(3, '3', '3', '3', '3', '3', '3', '3', '3', '9MOBILE', 'On', 'On', 'Off', 'On', 'Off', 'Off', 'Off', 'On', 'Off', 'Off'),
(4, '4', '4', '4', '4', '4', '4', '4', '4', 'AIRTEL', 'On', 'Off', 'Off', 'Off', 'Off', 'Off', 'Off', 'On', 'Off', 'Off');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `msgId` int(200) NOT NULL,
  `msgfor` tinyint(4) NOT NULL,
  `subject` varchar(200) NOT NULL,
  `message` text NOT NULL,
  `status` tinyint(3) NOT NULL DEFAULT 0,
  `dPosted` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`msgId`, `msgfor`, `subject`, `message`, `status`, `dPosted`) VALUES
(42, 3, ' Special MTN Gifting ', '750MB N210 1GB N255 \r\n2GB N518 3GB N800 \r\n', 0, '2024-02-25 09:39:57'),
(43, 3, 'WELCOME TO VTU TELECOM COMPANY', 'Kusa Kudi Ta Kuda Bank \r\nBabu Change din ko naira Biyar ', 0, '2024-02-26 23:22:54'),
(44, 3, 'WELCOME TO VTU TELECOM COMPANY', 'Kusa Kudi Ta Kuda Bank \r\nBabu Change din ko naira Biyar ', 0, '2024-02-26 23:26:33');

-- --------------------------------------------------------

--
-- Table structure for table `sitesettings`
--

CREATE TABLE `sitesettings` (
  `sId` int(200) NOT NULL,
  `sitename` varchar(20) DEFAULT NULL,
  `siteurl` varchar(100) DEFAULT NULL,
  `agentupgrade` varchar(20) DEFAULT NULL,
  `vendorupgrade` varchar(20) DEFAULT NULL,
  `apidocumentation` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `whatsapp` varchar(20) DEFAULT NULL,
  `whatsappgroup` varchar(100) DEFAULT NULL,
  `facebook` varchar(10) DEFAULT NULL,
  `twitter` varchar(200) DEFAULT NULL,
  `instagram` varchar(200) DEFAULT NULL,
  `telegram` varchar(100) DEFAULT NULL,
  `referalupgradebonus` float NOT NULL DEFAULT 100,
  `referalairtimebonus` float NOT NULL DEFAULT 1,
  `referaldatabonus` float NOT NULL DEFAULT 1,
  `referalwalletbonus` float NOT NULL DEFAULT 1,
  `referalcablebonus` float NOT NULL DEFAULT 1,
  `referalexambonus` float NOT NULL DEFAULT 1,
  `referalmeterbonus` float NOT NULL DEFAULT 1,
  `wallettowalletcharges` float NOT NULL DEFAULT 50,
  `sitecolor` varchar(10) NOT NULL DEFAULT '#0000e6',
  `logindesign` varchar(10) NOT NULL DEFAULT '5',
  `homedesign` varchar(10) NOT NULL DEFAULT '5',
  `notificationStatus` varchar(5) NOT NULL DEFAULT 'Off',
  `accountname` varchar(50) DEFAULT NULL,
  `accountno` varchar(15) DEFAULT NULL,
  `bankname` varchar(20) DEFAULT NULL,
  `electricitycharges` varchar(5) DEFAULT NULL,
  `airtimemin` varchar(10) NOT NULL DEFAULT '50',
  `airtimemax` varchar(10) NOT NULL DEFAULT '500'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `sitesettings`
--

INSERT INTO `sitesettings` (`sId`, `sitename`, `siteurl`, `agentupgrade`, `vendorupgrade`, `apidocumentation`, `phone`, `email`, `whatsapp`, `whatsappgroup`, `facebook`, `twitter`, `instagram`, `telegram`, `referalupgradebonus`, `referalairtimebonus`, `referaldatabonus`, `referalwalletbonus`, `referalcablebonus`, `referalexambonus`, `referalmeterbonus`, `wallettowalletcharges`, `sitecolor`, `logindesign`, `homedesign`, `notificationStatus`, `accountname`, `accountno`, `bankname`, `electricitycharges`, `airtimemin`, `airtimemax`) VALUES
(1, 'ZeeBills', 'https://app.zeebills.co/mobile/', '1000', '2000', '/mobile/home/apidocumentation', '+2349035785360', 'support@zeebills.co', '+2349035785360', '#', ' https://w', '#', 'https://www.instagram.com/zeebills.co?igsh=bnBuNnFoY3A0Njd5', '#', 400, 0, 0, 0, 2, 1, 1, 10000000000, '#070b3b', '5', '1', 'Off', 'none', 'none', 'none', '150', '50', '500');

-- --------------------------------------------------------

--
-- Table structure for table `subscribers`
--

CREATE TABLE `subscribers` (
  `sId` int(200) NOT NULL,
  `sApiKey` varchar(200) NOT NULL,
  `sFname` varchar(50) NOT NULL,
  `sLname` varchar(50) NOT NULL,
  `sEmail` varchar(50) DEFAULT NULL,
  `sPhone` varchar(20) NOT NULL,
  `sPass` varchar(150) NOT NULL,
  `sState` varchar(50) NOT NULL,
  `sPin` int(10) NOT NULL DEFAULT 1234,
  `sPinStatus` tinyint(3) DEFAULT 0,
  `sType` tinyint(10) NOT NULL DEFAULT 1,
  `sWallet` float NOT NULL DEFAULT 0,
  `sRefWallet` float NOT NULL DEFAULT 0,
  `sBankNo` varchar(20) DEFAULT NULL,
  `sRolexBank` varchar(20) DEFAULT NULL,
  `sSterlingBank` varchar(20) DEFAULT NULL,
  `sFidelityBank` varchar(20) DEFAULT NULL,
  `sKudaBank` varchar(30) DEFAULT NULL,
  `sAsfiyBank` varchar(30) DEFAULT NULL,
  `sGtBank` varchar(30) DEFAULT NULL,
  `sBankName` varchar(30) DEFAULT NULL,
  `sRegStatus` tinyint(5) NOT NULL DEFAULT 3,
  `sVerCode` smallint(20) NOT NULL DEFAULT 0,
  `sRegDate` datetime NOT NULL DEFAULT current_timestamp(),
  `sLastActivity` datetime DEFAULT NULL,
  `sReferal` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `subscribers`
--

INSERT INTO `subscribers` (`sId`, `sApiKey`, `sFname`, `sLname`, `sEmail`, `sPhone`, `sPass`, `sState`, `sPin`, `sPinStatus`, `sType`, `sWallet`, `sRefWallet`, `sBankNo`, `sRolexBank`, `sSterlingBank`, `sFidelityBank`, `sKudaBank`, `sAsfiyBank`, `sGtBank`, `sBankName`, `sRegStatus`, `sVerCode`, `sRegDate`, `sLastActivity`, `sReferal`) VALUES
(2, 'l3fAx0Fbzm6315w7d8CCd2xIAsCBr8Bhx23AknEaCAv9AG9yCCpc4C3Bc5J41745507053', 'Mubarak ', 'Ghazali', 'ghazalimubarak2@gmail.com', '08147469129', '385340498d', 'Lagos', 54321, 0, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 6257, '2025-04-24 11:04:13', '2025-04-24 16:44:09', ''),
(3, 'kp3xc9JCAmo71G70gBb2A8l5tqz3fAdcBaBBe2CCAxAECsHCvi5CC6b16d2r1745508802', 'Yusuf', 'Saifurahman', 'saif28ksl@gmail.com', '08156240305', '48e1c496a6', 'Abuja FCT', 12123, 0, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 4008, '2025-04-24 11:33:22', '2025-05-16 14:55:41', ''),
(4, 'arIo2A82eCvAxA2Hl468C1CD5b3x3kfzC65h3Acg0Bcw9d9J7nBCqAA1Cd7B1748593137', 'Emmanuel', 'Peter', 'maipandapeter143@gmail.com', '07060737815', '63d5f55760', 'Adamawa', 25800, 0, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 6759, '2025-05-30 04:18:57', '2025-05-30 09:20:36', ''),
(5, 'y5A5ahsAk0boCerAF9C623HxqA2c7B3318xB1CbxpCdd6AtCABvx8A3G4fDC1748907961', 'Samuel', 'King', 'samuelkingng@gmail.com', '08107526542', '385cbf3528', 'Lagos', 12592, 0, 1, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 3519, '2025-06-02 19:46:01', '2025-06-03 00:47:27', '');

-- --------------------------------------------------------

--
-- Table structure for table `sysusers`
--

CREATE TABLE `sysusers` (
  `sysId` int(100) NOT NULL,
  `sysName` varchar(50) NOT NULL,
  `sysRole` tinyint(2) NOT NULL,
  `sysUsername` varchar(20) NOT NULL,
  `sysToken` varchar(30) NOT NULL,
  `sysStatus` tinyint(2) NOT NULL DEFAULT 0,
  `sysPinToken` varchar(30) NOT NULL DEFAULT '03d258c7ef',
  `sysPinStatus` tinyint(2) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `sysusers`
--

INSERT INTO `sysusers` (`sysId`, `sysName`, `sysRole`, `sysUsername`, `sysToken`, `sysStatus`, `sysPinToken`, `sysPinStatus`) VALUES
(3, 'Admin ', 1, 'admin', 'admin', 0, '05723f16df', 0);

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `tId` int(200) NOT NULL,
  `sId` int(100) NOT NULL,
  `transref` varchar(255) NOT NULL,
  `servicename` varchar(100) NOT NULL,
  `servicedesc` varchar(255) NOT NULL,
  `amount` varchar(100) NOT NULL,
  `status` tinyint(5) NOT NULL,
  `oldbal` varchar(100) NOT NULL,
  `newbal` varchar(100) NOT NULL,
  `profit` float NOT NULL DEFAULT 0,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`tId`, `sId`, `transref`, `servicename`, `servicedesc`, `amount`, `status`, `oldbal`, `newbal`, `profit`, `date`) VALUES
(1, 1, '57701708975880', 'Airtime To Cash', 'MTN Airtime To Cash Request Of N10000 At The Rate Of N9300 From Phone Number 07026117709.', '9300', 0, '-10', '-10', 700, '2024-02-26 20:31:42'),
(2, 1, 'AIRTIME_SWAP_89021708975981', 'Wallet Credit', 'Wallet Credit of N9300 for user sunusihabibkasim6@gmail.com. Reason: Payment For Airtime To Cash', '9300', 0, '-10', '9290', 0, '2024-02-26 20:33:01'),
(3, 1, '35781708976020', 'Data', 'Purchase of AIRTEL 500MB Airtel  Corporate 30 Days Plan for phone number 09047223564', '110', 0, '9290', '9180', 10, '2024-02-26 20:34:12'),
(4, 1, '25671708978705', 'Data', 'Purchase of MTN 1GB SME 30 Days Plan for phone number 07067803322', '257', 0, '9180', '8923', 3, '2024-02-26 21:18:53'),
(5, 1, 'KUDA_240227474158', 'Wallet Topup', 'Wallet funding of N100 via Kuda bank transfer with a service charges of N30. You wallet have been credited with N70', '70', 0, '8923', '8993', 0, '2024-02-27 07:06:19');

-- --------------------------------------------------------

--
-- Table structure for table `userlogin`
--

CREATE TABLE `userlogin` (
  `id` int(200) NOT NULL,
  `user` int(100) NOT NULL,
  `token` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `userlogin`
--

INSERT INTO `userlogin` (`id`, `user`, `token`) VALUES
(1, 1, '1708975786JrnBsolpvI578'),
(2, 1, '1708975786CtHplvroxG513'),
(3, 1, '1708975799wzlEtDxyrJ521'),
(4, 1, '1708976745pvHnIxworz258'),
(5, 1, '1708979735BtJvpqnEoG113'),
(6, 1, '1709007804BFxvwHktDn545'),
(7, 1, '1709007804JwGtExvsrF917'),
(8, 1, '1709007821pCBlxnHGIs143'),
(9, 1, '1709009608wlAHknmzpE876'),
(10, 2, '1745507054GtrxpIFzAq368'),
(11, 3, '1745508802kADpvytGzq442'),
(12, 2, '1745509437IrByElxnvk649'),
(13, 3, '1746286673lmHJBFwCxp607'),
(14, 3, '1746700892DCvsnyArqo281'),
(15, 3, '1747403373kxlFJrwAtq512'),
(16, 4, '1748593137omtvrHIxDs792'),
(17, 5, '1748907961GvBpzCEwkq416');

-- --------------------------------------------------------

--
-- Table structure for table `uservisits`
--

CREATE TABLE `uservisits` (
  `id` int(200) NOT NULL,
  `user` int(100) NOT NULL,
  `state` varchar(10) NOT NULL,
  `visitTime` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `uservisits`
--

INSERT INTO `uservisits` (`id`, `user`, `state`, `visitTime`) VALUES
(1, 1, 'Kano', '1708975789'),
(2, 1, 'Kano', '1708975807'),
(3, 1, 'Kano', '1708976749'),
(4, 1, 'Kano', '1709007824'),
(5, 1, 'Kano', '1709009610'),
(6, 2, 'Lagos', '1745507061'),
(7, 3, 'Abuja FCT', '1745508809'),
(8, 2, 'Lagos', '1745509445'),
(9, 3, 'Abuja FCT', '1747403377'),
(10, 4, 'Adamawa', '1748593147'),
(11, 5, 'Lagos', '1748907969');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `airtime`
--
ALTER TABLE `airtime`
  ADD PRIMARY KEY (`aId`);

--
-- Indexes for table `airtimepinprice`
--
ALTER TABLE `airtimepinprice`
  ADD PRIMARY KEY (`aId`);

--
-- Indexes for table `apiconfigs`
--
ALTER TABLE `apiconfigs`
  ADD PRIMARY KEY (`aId`);

--
-- Indexes for table `apilinks`
--
ALTER TABLE `apilinks`
  ADD PRIMARY KEY (`aId`);

--
-- Indexes for table `cableid`
--
ALTER TABLE `cableid`
  ADD PRIMARY KEY (`cId`);

--
-- Indexes for table `cableplans`
--
ALTER TABLE `cableplans`
  ADD PRIMARY KEY (`cpId`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`msgId`);

--
-- Indexes for table `datapins`
--
ALTER TABLE `datapins`
  ADD PRIMARY KEY (`dpId`);

--
-- Indexes for table `dataplans`
--
ALTER TABLE `dataplans`
  ADD PRIMARY KEY (`pId`);

--
-- Indexes for table `electricityid`
--
ALTER TABLE `electricityid`
  ADD PRIMARY KEY (`eId`);

--
-- Indexes for table `examid`
--
ALTER TABLE `examid`
  ADD PRIMARY KEY (`eId`);

--
-- Indexes for table `networkid`
--
ALTER TABLE `networkid`
  ADD PRIMARY KEY (`nId`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`msgId`);

--
-- Indexes for table `sitesettings`
--
ALTER TABLE `sitesettings`
  ADD PRIMARY KEY (`sId`);

--
-- Indexes for table `subscribers`
--
ALTER TABLE `subscribers`
  ADD PRIMARY KEY (`sId`),
  ADD UNIQUE KEY `sApiKey` (`sApiKey`),
  ADD UNIQUE KEY `sPhone` (`sPhone`),
  ADD UNIQUE KEY `sEmail` (`sEmail`);

--
-- Indexes for table `sysusers`
--
ALTER TABLE `sysusers`
  ADD PRIMARY KEY (`sysId`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`tId`),
  ADD UNIQUE KEY `transref` (`transref`);

--
-- Indexes for table `userlogin`
--
ALTER TABLE `userlogin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `uservisits`
--
ALTER TABLE `uservisits`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `airtime`
--
ALTER TABLE `airtime`
  MODIFY `aId` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `airtimepinprice`
--
ALTER TABLE `airtimepinprice`
  MODIFY `aId` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `apiconfigs`
--
ALTER TABLE `apiconfigs`
  MODIFY `aId` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=96;

--
-- AUTO_INCREMENT for table `apilinks`
--
ALTER TABLE `apilinks`
  MODIFY `aId` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;

--
-- AUTO_INCREMENT for table `cableid`
--
ALTER TABLE `cableid`
  MODIFY `cId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `cableplans`
--
ALTER TABLE `cableplans`
  MODIFY `cpId` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `msgId` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `datapins`
--
ALTER TABLE `datapins`
  MODIFY `dpId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `dataplans`
--
ALTER TABLE `dataplans`
  MODIFY `pId` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `electricityid`
--
ALTER TABLE `electricityid`
  MODIFY `eId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `examid`
--
ALTER TABLE `examid`
  MODIFY `eId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `networkid`
--
ALTER TABLE `networkid`
  MODIFY `nId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `msgId` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `sitesettings`
--
ALTER TABLE `sitesettings`
  MODIFY `sId` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `subscribers`
--
ALTER TABLE `subscribers`
  MODIFY `sId` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `sysusers`
--
ALTER TABLE `sysusers`
  MODIFY `sysId` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `tId` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `userlogin`
--
ALTER TABLE `userlogin`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `uservisits`
--
ALTER TABLE `uservisits`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
